import random

#intro duck
print("Welcome to WordsWordsWords!!!")

print("You will have 6 guesses to guess the right letter in the word.")
print("After you guess the right letter, it will go in to your word bank for later.")
print("You then have 6 attempts to guess the word.\n" +
      "Using the letter you found before.\n" + "Good luck!\n")


while True:
  play = input("Would you like to play? (y/n): ").lower()
  if play == "y" or play == "yes":
    print("\nGreat, let's get started!")
    break
  if play == "n" or play == "no":
    print("\nLOSER")
    exit()
  else:
    print("\nDo you know how to type? It's a simple yes or no.\n")


word_length = int(input("How many letters do you want your word to be? "))
if word_length < 3 or word_length > 8:
  print("Invalid input. Please enter a number between 3 and 8.")


print(f"\nYou have chosen an {word_length} letter word. Good luck!\n")


words_by_length = {
  3: ["All", "Ape", "Bar", "Bat", "Cap", "Caw", "Dox", "Dug", "Eat", 
    "Egg", "Far", "Fat", "Gib", "Gnu", "Him", "Hex"],
  4: ["Able", "Acid", "Bath", "Bead", "Cabs", "Cast", "Demo", "Duck",
      "Echo","Eros", "Face", "Fyce", "Gaid", "Gawd", "Half", "Heal"],
  5: ["Apeak", "Abamp", "Brick", "Bawdy", "Chivy", "Chyme", "Ditzy", "Dumka",
    "Epics", "Elvan", "Faxes", "Frock", "Given", "Gawsy", "Helix", "Hawks"],
  6: ["Abelia", "Ablate", "Blowzy", "Buqsha", "Cables", "Cabmen", "Dermic",
    "Dezinc", "Exotic", "Enolic", "Fundic", "Frolic", "Gaited", "Galiot",
    "Habits", "Hacked"],
  7: ["Abdomen", "Ableist", "Backfit", "Baetyls", "Cabined", "Cbrito", "Daglock", 
  "Dakoits", "earlies","Ebonics", "Fabling", "Failure", "Gahnite", "Galenic", 
  "Hackies", "Hahnium"],
  8: ["Abjectly", "Aborting", "Bachelor", "Backdrop", "Cajolers", "Cajoling", "Dactylus",
  "Darksome","Earldoms", "Earplugs", "Fabulist", "Facemask", "Gapeworm", "Gambeson",
  "Halogens", "Hachures"]
}


chosen_word = random.choice(words_by_length[word_length]).lower()
word_bank = set()
guesses_left = 5 # CHANGE THIS LATER FOR DIFFERENT WORDS??


while guesses_left > 0:
  print(f"You have {guesses_left} guesses left.")
  guess_letter = input("Guess a letter: ").lower()

  
  if len(guess_letter) != 1 or guess_letter not in 'abcdefghijklmnopqrstuvwxyz':
    print("Invalid input. Please enter a single letter.")
    continue

  if guess_letter in word_bank:
    print(f"You've already guessed '{guess_letter}'.")
    continue

  if guess_letter in chosen_word:
    print(f"'{guess_letter}' is in the word!")
    word_bank.add(guess_letter)
  else:
    print(f"'{guess_letter}' is not in the word.")
    guesses_left -= 1

  if len(word_bank) == word_length:
    print("\nCongratulations! You've guessed all the letters.")
    break


if len(word_bank) != word_length:
  print("\nOut of guesses. Better luck next time!")
  print(f"The word was: {chosen_word.capitalize()}")


# if word_length == 1:
#   print("You have chosen a 3 letter word.")
#   chosen_word= random.choice(Three)
  
# if word_length == 2:
#   print("You have chosen a 4 letter word.")
#   chosen_word= random.choice(Four)

# if word_length == 3:
#   print("You have chosen a 5 letter word.")
#   chosen_word= random.choice(Five)

# if word_length == 4:
#   print("You have chosen a 6 letter word.")
#   chosen_word= random.choice(Six)

# if word_length == 5:
#   print("You have chosen a 7 letter word.")
#   chosen_word= random.choice(Seven)

# if word_length == 6:
#   print("You have chosen a 8 letter word.")
#   chosen_word= random.choice(Eight)
#word bank

# alphabet = ["a","b","c","d","e","f","g","h","i","j","k","l","m",
#             "n","o","p","q","r","s","t","u","v","w","x","y","z"]

# guess_letter = [ ]
# guessed = [ ]
# chosen_word = [ ]
# counter = 10

# guess_letter = input("Guess a letter: ")
# guess_letter = guess_letter.lower()

# if guess_letter in chosen_word:
#   print(f"\t\t'{guess_letter}' is in the word!")
# if guess_letter not in chosen_word:
#   print(f"\t\t'{guess_letter}' is not in the word.")
#   counter = -1
#   print(f"\t\tYou have {counter} guesses left.")
# else:
#     print(f"\t\t'{guess_letter}' is not a letter.")
# if guess_letter in guessed:
#   print(f"\t\tYou already guessed '{guess_letter}'!")
    


play = input("Would you like to see the definition? (y/n): ")
if play == "y":
  print(("Great! Good for you! look it up!"))
  print("https://www.dictionary.com/browse/")
  exit()

if play == "n":
  print("Maybe next time!")
  exit()